java -cp dbvis.jar:lib/* br.unesp.amoraes.dbvis.App install
